def changelist(sentence):
    sen_morph=[]#여기에 원래형식대로 맞춰줌
    mem_morph=[]#인덱스 기억함
    k = 0
    for word in sentence:
        mem_morph.append = k
        for morph in word:
            sen_morph.append(morph)
            k+=1
    mem_morph.append = k
    e=sent2elmo(sen_morph)
    for idx in range(len(mem_moprh)):
        add=torch.cat(e[mem_morph[idx],e[mem_morph[idx+1]-1])
        new=torch.cat(new,add)
    return new